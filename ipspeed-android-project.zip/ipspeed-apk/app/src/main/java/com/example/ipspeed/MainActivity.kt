package com.example.ipspeed

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var output: TextView
    private lateinit var statusOutput: TextView
    private lateinit var speedFilter: EditText
    private lateinit var target: EditText
    private lateinit var connectWorkers: EditText
    private lateinit var downloadWorkers: EditText
    private lateinit var topN: EditText
    private var sourcePage = false
    private var running = AtomicBoolean(false)
    private var process: Process? = null
    private val resultLines = mutableListOf<String>()
    private var localEnabled: CheckBox? = null
    private var networkEnabled: CheckBox? = null
    private var urlsEditor: EditText? = null
    private var sourceStats: TextView? = null
    private val pickFile = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMain()
    }

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(12), dp(16), dp(20))
    }

    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        setPadding(0, dp(10), 0, dp(5))
    }

    private fun edit(hintText: String, value: String, single: Boolean = true): EditText = EditText(this).apply {
        hint = hintText
        setText(value)
        textSize = 16f
        if (single) setSingleLine(true) else {
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
        }
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
    }

    private fun addField(parent: LinearLayout, title: String, field: EditText) {
        parent.addView(label(title))
        parent.addView(field, LinearLayout.LayoutParams(-1, -2))
    }

    private fun shell(title: String): LinearLayout {
        root = column()
        root.addView(TextView(this).apply {
            text = title
            textSize = 24f
            setPadding(0, 0, 0, dp(8))
        })
        val scroll = ScrollView(this).apply { isFillViewport = true }
        scroll.addView(root)
        setContentView(scroll)
        return root
    }

    private fun showMain() {
        sourcePage = false
        val page = shell("IP 测速")
        target = edit("HTTPS 测速地址", prefs.getString("target", "https://cesu.dxgees.ggff.net")!!)
        connectWorkers = edit("连通性并发数", prefs.getString("connect", "300")!!)
        downloadWorkers = edit("下载测速并发数", prefs.getString("download", "100")!!)
        topN = edit("按延迟筛选参与下载的 IP 数量", prefs.getString("topn", "20")!!)
        speedFilter = edit("最低显示速度（MiB/s）", prefs.getString("threshold", "0.5")!!)
        addField(page, "测速地址", target)
        addField(page, "连通性检测并发数", connectWorkers)
        addField(page, "下载测速并发数", downloadWorkers)
        addField(page, "参与下载测速的 IP 数量", topN)
        addField(page, "最低显示速度（只筛选界面结果）", speedFilter)
        page.addView(button("IP 来源管理") { saveMainSettings(); showSources() })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("开始测速") { startTest() }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(button("停止测速") { stopTest() }, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(controls)
        page.addView(label("合格结果（测试中显示已收到的结果；结束后显示全部结果）"))
        statusOutput = TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(4), 0, dp(4))
            text = "等待开始"
        }
        page.addView(statusOutput)
        output = TextView(this).apply {
            textSize = 15f
            setTextIsSelectable(true)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            minHeight = dp(180)
            setBackgroundColor(0xFFF3F5F7.toInt())
        }
        val resultScroll = ScrollView(this).apply { addView(output) }
        page.addView(resultScroll, LinearLayout.LayoutParams(-1, dp(260)))
        page.addView(button("复制结果") { copyFilteredResults() })
        page.addView(label("说明：原始 Go 测速程序独立运行；此界面只负责参数、来源和结果展示。"))
    }

    private fun showSources() {
        sourcePage = true
        val page = shell("IP 来源管理")
        page.addView(button("选择 TXT / CSV 文件") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "text/csv", "application/csv", "application/vnd.ms-excel"))
            }
            startActivityForResult(intent, pickFile)
        })
        sourceStats = label("有效 IPv4：${prefs.getInt("valid_count", 0)} 个；重复 IPv4：${prefs.getInt("duplicate_count", 0)} 个")
        page.addView(sourceStats)
        page.addView(label("TXT 规则：忽略行首空格；每行必须以 IPv4 开始，只保留开头 IPv4；IPv6 不支持。CSV 会扫描字段中的 IPv4。"))
        localEnabled = CheckBox(this).apply {
            text = "启用已导入的本地 ips.txt"
            isChecked = prefs.getBoolean("local_enabled", false) && File(filesDir, "ips.txt").exists()
        }
        networkEnabled = CheckBox(this).apply {
            text = "启用网络 IP 来源"
            isChecked = prefs.getBoolean("network_enabled", true)
        }
        page.addView(localEnabled)
        page.addView(networkEnabled)
        page.addView(label("网络 URL（每行一个）"))
        urlsEditor = edit("每行输入一个 HTTPS URL", prefs.getString("urls", "https://zip.cm.edu.kg/all.txt\nhttps://countrymerge.pages.dev/all.txt")!!, false)
        page.addView(urlsEditor)
        page.addView(button("保存网络 URL") { saveSourceSettings(); toast("网络 URL 已保存") })
        page.addView(button("保存设置并返回") {
            saveSourceSettings()
            showMain()
        })
        page.addView(label("本地文件和网络来源独立启用。启用本地来源前请先选择文件。所有来源合并后由原程序去重。"))
    }

    private fun saveMainSettings() {
        prefs.edit()
            .putString("target", target.text.toString().trim())
            .putString("connect", connectWorkers.text.toString().trim())
            .putString("download", downloadWorkers.text.toString().trim())
            .putString("topn", topN.text.toString().trim())
            .putString("threshold", speedFilter.text.toString().trim())
            .apply()
    }

    private fun saveSourceSettings() {
        val local = localEnabled?.isChecked == true
        val network = networkEnabled?.isChecked == true
        val urls = urlsEditor?.text?.toString().orEmpty().lines().map { it.trim() }.filter { it.isNotEmpty() }
        prefs.edit()
            .putBoolean("local_enabled", local && File(filesDir, "ips.txt").exists())
            .putBoolean("network_enabled", network)
            .putString("urls", urls.joinToString("\n"))
            .apply()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickFile || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("无法读取所选文件")
            val name = queryDisplayName(uri).lowercase(Locale.ROOT)
            val isCsv = name.endsWith(".csv") || contentResolver.getType(uri)?.contains("csv", true) == true
            val (ips, duplicates) = parseImportedIPs(raw, isCsv)
            if (ips.isEmpty()) throw IllegalArgumentException("没有识别到有效 IPv4")
            File(filesDir, "ips.txt").writeText(ips.joinToString("\n") + "\n")
            prefs.edit().putBoolean("local_enabled", true)
                .putInt("valid_count", ips.size).putInt("duplicate_count", duplicates).apply()
            localEnabled?.isChecked = true
            sourceStats?.text = "有效 IPv4：${ips.size} 个；重复 IPv4：$duplicates 个"
            toast("已导入 ${ips.size} 个唯一 IPv4")
        } catch (e: Exception) {
            toast("导入失败：${e.message ?: "未知错误"}")
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null) ?: return uri.lastPathSegment.orEmpty()
        cursor.use {
            val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && it.moveToFirst()) return it.getString(index) ?: ""
        }
        return uri.lastPathSegment.orEmpty()
    }

    private fun parseImportedIPs(text: String, csv: Boolean): Pair<List<String>, Int> {
        val found = mutableListOf<String>()
        val seen = mutableSetOf<String>()
        var duplicates = 0
        val pattern = Regex("(?:[0-9]{1,3}\\.){3}[0-9]{1,3}")
        val candidates = if (csv) {
            text.lines().flatMap { line -> splitCsvLine(line) }
        } else {
            text.lines().mapNotNull { line ->
                val trimmed = line.trimStart()
                pattern.find(trimmed)?.takeIf { it.range.first == 0 }?.value
            }
        }
        for (candidate in candidates) {
            val match = pattern.find(candidate)?.value ?: continue
            val parts = match.split('.').mapNotNull { it.toIntOrNull() }
            if (parts.size != 4 || parts.any { it !in 0..255 }) continue
            val canonical = parts.joinToString(".")
            if (seen.add(canonical)) found.add(canonical) else duplicates++
        }
        return found to duplicates
    }

    private fun splitCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { cell.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { out.add(cell.toString()); cell.setLength(0) }
                else -> cell.append(c)
            }
            i++
        }
        out.add(cell.toString())
        return out
    }

    private fun startTest() {
        if (!running.compareAndSet(false, true)) { toast("测速正在进行中"); return }
        saveMainSettings()
        saveSourceSettings()
        val url = target.text.toString().trim()
        val c = connectWorkers.text.toString().trim().toIntOrNull()
        val d = downloadWorkers.text.toString().trim().toIntOrNull()
        val n = topN.text.toString().trim().toIntOrNull()
        if (!url.startsWith("https://") || c == null || c <= 0 || d == null || d <= 0 || n == null || n <= 0) {
            running.set(false); toast("请检查测速地址和并发/数量参数"); return
        }
        val local = prefs.getBoolean("local_enabled", false)
        val network = prefs.getBoolean("network_enabled", true)
        val ipFile = File(filesDir, "ips.txt")
        if (local && !ipFile.exists()) { running.set(false); toast("本地来源已启用，但尚未选择文件"); return }
        if (!local) ipFile.delete()
        val urls = if (network) prefs.getString("urls", "").orEmpty().lines().map { it.trim() }.filter { it.isNotEmpty() } else emptyList()
        if (!local && (!network || urls.isEmpty())) { running.set(false); toast("请至少启用一个有效 IP 来源"); return }
        resultLines.clear()
        output.text = ""
        statusOutput.text = "正在启动原始测速核心……"
        Thread {
            try {
                val executable = File(applicationInfo.nativeLibraryDir, "libsss.so")
                if (!executable.exists()) throw IllegalStateException("APK 中没有找到测速核心 libsss.so")
                val args = mutableListOf(executable.absolutePath, url, c.toString(), d.toString(), n.toString(), "no")
                args.addAll(urls)
                val pb = ProcessBuilder(args).directory(filesDir).redirectErrorStream(true)
                process = pb.start()
                process!!.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        runOnUiThread {
                            if (line.contains('#') && Regex("^[0-9]{1,3}(?:\\.[0-9]{1,3}){3}#[0-9]+(?:\\.[0-9]+)?M$").matches(line.trim())) {
                                resultLines.add(line.trim())
                                renderFilteredResults()
                            }
                            statusOutput.text = line.takeLast(240)
                        }
                    }
                }
                val code = process?.waitFor() ?: -1
                runOnUiThread { statusOutput.text = "测速进程结束，退出码：$code"; renderFilteredResults() }
            } catch (e: Exception) {
                runOnUiThread { statusOutput.text = "启动/运行失败：${e.message}" }
            } finally {
                process = null
                running.set(false)
            }
        }.start()
    }

    private fun stopTest() {
        val p = process
        if (p == null) { toast("当前没有运行中的测速任务"); return }
        p.destroy()
        running.set(false)
        statusOutput.text = "已请求停止测速。"
    }

    private fun renderFilteredResults() {
        val threshold = speedFilter.text.toString().trim().toDoubleOrNull() ?: 0.5
        val filtered = resultLines.filter { line ->
            val speed = line.substringAfter('#').removeSuffix("M").toDoubleOrNull() ?: 0.0
            speed >= threshold
        }
        output.text = filtered.joinToString("\n")
    }

    private fun copyFilteredResults() {
        val threshold = speedFilter.text.toString().trim().toDoubleOrNull() ?: 0.5
        val text = resultLines.filter { line ->
            val speed = line.substringAfter('#').removeSuffix("M").toDoubleOrNull() ?: 0.0
            speed >= threshold
        }.joinToString("\n")
        if (text.isBlank()) { toast("没有符合阈值的结果可复制"); return }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("IP 测速结果", text))
        toast("已复制 ${text.lines().size} 条结果")
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
