# IPSpeedAndroid

Android GUI wrapper for the supplied Go CLI speed-test program. The supplied `myspeed.go` is kept as a standalone source file; the build workflow does not run `gofmt` on it. UI and Android integration are implemented separately.

## Build

Push this project to a GitHub repository's `main` branch, then open **Actions → Build APK → Run workflow**. The workflow compiles the Go core for Android arm64, builds the debug APK, and uploads the APK plus a SHA-256 record for the Go source.

## Important limitations

- The APK currently packages an Android arm64 executable and invokes it as a child process from the UI. It targets arm64 Android devices.
- The original core filters speeds below 0.5 MiB/s before printing. Because the core is intentionally unchanged, the UI can raise the display threshold but cannot reveal results below 0.5 MiB/s that the core never outputs.
- Stopping the child process terminates the running process; it does not modify the Go test implementation.
- This project has not been compiled or installed in this environment. Run the GitHub Actions workflow to verify the toolchain and device behavior before relying on the APK.
